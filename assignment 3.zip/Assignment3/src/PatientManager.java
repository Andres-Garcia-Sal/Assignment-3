import java.util.*;

public class PatientManager {
	private User loginUser;
	private ArrayList<Patient> allPatients;

	public PatientManager(User userNew, ArrayList<Patient> patient) {
		this.loginUser = userNew;
		this.allPatients = patient;
	}
	
	public void showProfile() {
		
	}
	
	public void editInfo() {
		Scanner scnr = new Scanner(System.in);
		
	}

}
