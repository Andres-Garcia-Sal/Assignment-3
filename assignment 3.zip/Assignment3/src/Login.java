import java.io.*;
import java.util.*;

public class Login {
	private ArrayList<String[]> insertData = new ArrayList<>();
	
	public void activeLogIn(Login manage) {
		boolean isTrue = false;
		Scanner scnr = new Scanner(System.in);
		
		System.out.println("Medical login System");
		System.out.print("Is this a Patient or Staff Member? [P] or [S]: ");
		char loginType = scnr.next().charAt(0);
		System.out.println();
		
		scnr.nextLine();
		
		while(loginType != 'P' && loginType != 'S') {
			System.out.print("Error, input invalid. Try Again: ");
			loginType = scnr.next().charAt(0);
			System.out.println();
			scnr.nextLine();
		}
		
		boolean loggedIn = false;
		
		while (!loggedIn) { 
	            System.out.print("Please enter Username: ");
	            String username = scnr.nextLine();
	            System.out.print("Please enter Password: ");
	            String password = scnr.nextLine();
	            System.out.println();

	            if (loginType == 'P') {
	                ArrayList<String[]> dataP = manage.loadData("C:\\Users\\andre\\OneDrive\\Desktop\\patient.csv");
	                if (validLogin(dataP, username, password)) {
	                    System.out.println("Login Successful");
	                    loggedIn = true; // Set to true to exit loop
	                } else {
	                    System.out.println("Error: login invalid. Try again.");
	                    System.out.println();
	                }
	            } else if (loginType == 'S') {
	                ArrayList<String[]> dataP = manage.loadData("C:\\Users\\andre\\OneDrive\\Desktop\\medicalstaff.csv");
	                if (validLogin(dataP, username, password)) {
	                    System.out.println("Login Successful");
	                    loggedIn = true; // Set to true to exit loop
	                } else {
	                    System.out.println("Error: login invalid. Try again.");
	                    System.out.println();
	                }
	            }
	        }
		
	}
	
	public boolean validLogin(ArrayList<String[]> dataP, String userName, String password) {
		boolean istrue = false;
		for(String[] user : dataP) {
			if(user[1].equals(userName) && user[2].equals(password)) {
				istrue = true;
				break;
			}
		}
		return istrue;
	}

	
	public ArrayList<String[]> loadData(String filePath) {
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(filePath));
            String line;
            while ((line = br.readLine()) != null && !line.isEmpty()) {
                String[] values = line.split(",");
                insertData.add(values);
            }
        } catch (IOException e) {
            e.printStackTrace();  // Handle the exception, could log or throw as needed
        } finally {
            try {
                if (br != null) {
                    br.close();  // Ensure the BufferedReader is closed
                }
            } catch (IOException e) {
                e.printStackTrace();  // Handle the exception during close
            }
        }
        return insertData;
    }

}
