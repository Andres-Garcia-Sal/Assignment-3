import java.util.*;
import java.io.*;
public class Driver {

	public static char loginType;
	
	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);
		
		Login manage = new Login();
		Login act = new Login();
		boolean istrue = true;
		
		while (istrue == true) {
	                act.activeLogIn(manage);
	                System.out.println();
	                break;  // Exit the loop if input is valid
		}
	}
}
