import java.util.*;
import java.io.*;
public class Driver {

	public static char loginType;
	
	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);
		
		Login manage = new Login();
		Login act = new Login();
		boolean istrue = true;
		
		while (istrue == true) {
	                act.activeLogIn(manage);
	                System.out.println();
	                System.out.println("--Main Menu--");
	                System.out.println("1. View Profile");
	                System.out.println("2. Edit Profile");
	                System.out.println("3. Look up patinet by ID");
	                System.out.println("4. Logout");
	                System.out.print("Please select a choice: ");
	                int choice = scnr.nextInt();
	                
	                switch(choice) {
	                case 4:
	                	System.out.println();
	                	System.out.println("Thank you for your use");
	                	System.exit(0);
	                case 2:
	                	//menu.editInfo();
	                case 1:
	                	
	                case 3:
	                	
	                }
	                
	                
	                
	                break;  // Exit the loop if input is valid
		}
	}
}
