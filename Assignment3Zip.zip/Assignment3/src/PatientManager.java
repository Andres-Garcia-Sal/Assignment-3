import java.util.*;

public class PatientManager{
	private User loginUser;
	private Patient currentP;
	private ArrayList<Patient> allPatients;

	public PatientManager(User userNew, ArrayList<String[]> patientData) {
		this.loginUser = userNew;
		this.allPatients = new ArrayList<>();
		
		for(String[] patientInfo: patientData) {
			 if (patientInfo.length >= 6) {
	                String id = patientInfo[0];
	                String username = patientInfo[1];
	                String password = patientInfo[2];
	                String name = patientInfo[3];
	                String email = patientInfo[4];
	                String treatment = patientInfo[5];
	                allPatients.add(new Patient(id, username, password, name, email, treatment));
	            }
		}
	}
	
	 public ArrayList<Patient> getPatients() {
	        return allPatients;
	    }
	 
	 public Patient getPatientById(String id) {
	        for (Patient patient : allPatients) {
	            if (patient.getID().equals(id)) {
	                return patient;
	            }
	        }
	        return null; // Patient not found
	    }

	public static void currentProfile() {
		
	}
	
	//Note, dont forget to include the report method/class in here or in sepereate class for that function to output
	

}
