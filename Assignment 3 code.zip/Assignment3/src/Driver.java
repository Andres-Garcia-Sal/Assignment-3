import java.util.*;
import java.io.*;
public class Driver {

	public static void main(String[] args) {
		Login manage = new Login();
		ArrayList<String[]> dataP  = manage.loadData("C:\\Users\\andre\\OneDrive\\Desktop\\patient.csv");
		ArrayList<String[]> dataM = manage.loadData("C:\\Users\\andre\\OneDrive\\Desktop\\medicalstaff.csv");
		boolean istrue = true;
		Login act = new Login();
		
		while(istrue == true) {
			act.activeLogIn();
			
			//if user is not found on either catagory, state error message
			
			System.out.println();
		}
		
		
		
		

	}

}
