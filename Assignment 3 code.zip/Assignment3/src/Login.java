import java.io.*;
import java.util.*;

public class Login {
	private ArrayList<String[]> insertData = new ArrayList<>();
	
	public void activeLogIn() {
		Scanner scnr = new Scanner(System.in);
		System.out.println("Medical login System");
		System.out.print("Please enter Username: ");
		String user = scnr.nextLine();
		System.out.print("Enter Password: ");
		String password = scnr.nextLine();
		System.out.print("Is this a Patient or Staff Member? [P] or [S]");
		char loginType = scnr.next().charAt(0);
	}
	
public ArrayList<String[]> loadData(String filePath) {
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(filePath));
            String line;
            while ((line = br.readLine()) != null && !line.isEmpty()) {
                String[] values = line.split(",");
                String user = values[1];
                String pass = values[2];
                insertData.add(values);
            }
        } catch (IOException e) {
            e.printStackTrace();  // Handle the exception, could log or throw as needed
        } finally {
            try {
                if (br != null) {
                    br.close();  // Ensure the BufferedReader is closed
                }
            } catch (IOException e) {
                e.printStackTrace();  // Handle the exception during close
            }
        }
        return insertData;
    }
}
